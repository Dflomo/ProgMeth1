#ifndef __RESIDENTIAL_H__
#define __RESIDENTIAL_H__

#include "map_item.h"


class Residential: public MapItem{
	public:
		Residential();
		virtual ~Residential();

		void tick();
		double collectTaxes();

	private:
		int capacity;
		double taxRevenue;

};

#endif