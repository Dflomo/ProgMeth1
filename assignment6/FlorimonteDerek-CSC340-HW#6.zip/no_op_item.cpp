#include "no_op_item.h"

NoOpItem:: NoOpItem(){

};

NoOpItem:: ~NoOpItem(){
	
};

void NoOpItem:: tick(){

};