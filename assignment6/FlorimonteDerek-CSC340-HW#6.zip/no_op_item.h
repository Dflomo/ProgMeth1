#ifndef __NO_OP_ITEM_H__
#define __NO_OP_ITEM_H__

#include "map_item.h"

class NoOpItem : public MapItem {
	public:
		NoOpItem();
		virtual ~NoOpItem();
		void tick();

		private:
};

#endif