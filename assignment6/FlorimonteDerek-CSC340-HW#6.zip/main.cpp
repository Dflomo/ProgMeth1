#include "inheritance_test.h"

int main() {
  InheritanceTest test;
  test.run_tests();

  return 0;
}