#ifndef __FACTORY_H__
#define __FACTORY_H__

#include "map_item.h"

class Factory : public MapItem{
	public:
		Factory();
		virtual ~Factory();

		void tick();
		void produceItem(int);
		int getProducedItem();
		int productionCount();
		int producedCount();
		Queue * production;
		Queue * produced;
	private:

		int countSinceLastProduced;
		// Queue * production;
		// Queue * produced;

};

#endif
