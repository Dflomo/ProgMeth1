#ifndef __MAP_ITEM_H__
#define __MAP_ITEM_H__

#include <iostream>

#include "queue.h"

using namespace std;

class MapItem{
	public:
		MapItem();
		virtual ~MapItem();
		virtual void tick() = 0;

};

#endif