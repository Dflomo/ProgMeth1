#include "residential.h"

Residential:: Residential(){
	capacity = 1;
	taxRevenue = 0;
};

Residential:: ~Residential(){
	
};

void Residential:: tick(){
	taxRevenue = capacity *.1;
};

double Residential:: collectTaxes(){
	double tempTax = taxRevenue;
	taxRevenue = 0;
	return tempTax;
};

