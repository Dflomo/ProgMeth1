#include "node.h"

//NODE Constructor
Node:: Node(int a){
	next = NULL;
	data = a;
}