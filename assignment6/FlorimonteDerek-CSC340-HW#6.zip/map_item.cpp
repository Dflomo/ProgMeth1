#include "map_item.h"

MapItem:: MapItem(){
	
};

MapItem:: ~MapItem(){
	
};

void MapItem:: tick(){

};